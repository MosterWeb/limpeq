<!DOCTYPE html>
<html dir="ltr" lang="es-ES">

<head>

    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <meta name="author" content="SemiColonWeb">
    <meta name="description" content="Create New &amp; Used Car Sale Websites with Canvas Template. Get Canvas to build powerful websites easily with the Highly Customizable &amp; Best Selling Bootstrap Template, today.">

    <!-- Font Imports -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Mukta+Vaani:wght@300;400;500;600;700&family=Open+Sans:wght@300;400;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Core Style -->
    <link rel="stylesheet" href="assets/style.css">

    <!-- Font Icons -->
    <link rel="stylesheet" href="assets/css/font-icons.css">
    <link rel="stylesheet" href="assets/demos/car/css/car-icons/style.css">

    <!-- Plugins/Components CSS -->
    <link rel="stylesheet" href="assets/css/swiper.css">
    <link rel="stylesheet" href="assets/css/components/bs-select.css">
    <link rel="stylesheet" href="assets/include/rs-plugin/css/settings.css" media="screen">
    <link rel="stylesheet" href="assets/include/rs-plugin/css/layers.css">
    <link rel="stylesheet" href="assets/include/rs-plugin/css/navigation.css">

    <!-- Niche Demos -->
    <link rel="stylesheet" href="assets/demos/car/car.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Document Title
	============================================= -->
    <title>Limpeq | Limpieza profesional de espacios</title>
    <link rel="icon" href="assets/images/fav.png" type="image/png">


    <style>
        .is-expanded-menu .mega-menu-content,
        .is-expanded-menu .sub-menu-container {

            background-color: #003083;

        }

        .button.button-border {
            --cnvs-btn-border-color: #ffffff;
            border: var(--cnvs-btn-border-width) solid var(--cnvs-btn-border-color);
            background: transparent;
            color: var(--cnvs-btn-border-color);
        }

        .button.button-dark:hover {
            background-color: #e7cb5c !important;
            color: #003083 !important;
            font-weight: 500;
        }

        /* Revolution Slider */
        .ares .tp-tab {
            border: 1px solid #eee;
        }

        .ares .tp-tab-content {
            margin-top: -4px;
        }

        .ares .tp-tab-content {
            padding: 15px 15px 15px 110px;
        }

        .ares .tp-tab-image {
            width: 80px;
            height: 80px;
        }

        /* Block header  */

        @media (min-width: 992px) {

            .block-nav-header-2 #top-bar.transparent-topbar {
                background: transparent !important;
                z-index: 399;
                border-bottom: 0;
            }

            .block-nav-header-2 .primary-menu {
                border-top: 1px solid rgba(255, 255, 255, 0.3);
            }

            .block-nav-header-2 .transparent-topbar+.transparent-header+#content {
                margin-top: -163px;
                /*  #header(height) + #top-bar(height) */
            }
        }

        .block-nav-header-2 .dark .top-links li>a,
        .block-nav-header-2 .dark #top-social li a {
            color: #f5f5f5;
        }

        .block-nav-header-2 .dark #top-social li,
        .block-nav-header-2 .top-links-item {
            border-left: 0;
        }

        .dark #header-wrap:not(.not-dark) #logo .logo-dark,
        .dark .header-row:not(.not-dark) #logo .logo-dark {
            display: flex;
            height: 90px !important;
            padding: 10px 0;
        }
    </style>

</head>

<body class="stretched side-push-panel" data-loader-html="<div><img src='assets/demos/car/images/page-loader.gif' alt='Loader'></div>">
    <div id="loading-rel" class="css3-spinner" style="--cnvs-loader-color: #003083;">
        <div class="css3-spinner-ball-scale-multiple">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>

    <!-- Side Panel Overlay -->
    <div class="body-overlay"></div>

    <!-- Side Panel -->


    <!-- Document Wrapper
	============================================= -->
    <div id="wrapper">

        <!-- Header
		============================================= -->
        <div id="top-bar" class="transparent-topbar dark py-md-2">
            <div class="container">

                <div class="row align-items-center">

                    <div style="margin-right: 0!important;" class="col-12 col-lg-3 col-md-2">
                        <div class="top-links d-flex justify-content-center justify-content-lg-start">
                            <ul class="top-links-container">
                                <li class="top-links-item"><a href="#">Teléfonos</a>
                                    <ul class="top-links-sub-menu" style="width: 160px; left: 0;">
                                    
                                    <li class="top-links-item"><a style="font-weight: 700;" href="tel:+525555351555;ext=121">(55) 5535–1555 ext.121</a></li>
<li class="top-links-item"><a style="font-weight: 700;" href="tel:+525555351888;ext=104">(55) 5535–1888 ext.104</a></li>

                                                
                                    </ul>
                                </li>
                                <li class="top-links-item"><a  style="font-weight: 700;" class="d-flex" href="https://wa.me/525530400966"><i class="bi-whatsapp"></i>5530400966</a></li>
                               
                                
                            </ul>
                        </div><!-- .top-links end -->
                    </div>

                 
                    

                    <div class="col-12 col-lg-6 col-md-8">
                        <!-- Top Links
						============================================= -->
                        <div class="top-links">
                            <ul class="top-links-container">
                                <li class="top-links-item px-1 ls-2"><a href="./preguntas-frecuentes.php">Preguntas
                                        frecuentes</a></li>
                                <li class="top-links-item px-1 ls-2"><a href="mailto:cotizaciones@limpeq.com"><i class="uil uil-fast-mail fa-2x"></i>cotizaciones@limpeq.com</a>
                                </li>
                            </ul>
                        </div><!-- .top-links end -->
                    </div>

                    <div class="col-12 col-lg-3 col-md-2">
                        <!-- Top Social
						============================================= -->
                        <ul id="top-social" class="justify-content-center justify-content-lg-end">
                            <li><a href="https://www.facebook.com/limpeqoficial" class="h-bg-facebook"><span class="ts-icon"><i class="fa-brands fa-facebook-f"></i></span><span class="ts-text">Facebook</span></a></li>
                            <li><a href="https://www.tiktok.com/@limpeqoficial" class="h-bg-x-twitter"><span class="ts-icon"><i class="fa-brands fa-tiktok"></i></span><span class="ts-text">TikTok</span></a></li>
                            <li><a href="https://www.instagram.com/limpeqoficial/" class="h-bg-instagram"><span class="ts-icon"><i class="fa-brands fa-instagram"></i></span><span class="ts-text">Instagram</span></a></li>
                        </ul><!-- #top-social end -->

                    </div>
                </div>

            </div>
        </div><!-- #top-bar end -->

        <!-- Header
		============================================= -->
        <header id="header" class="transparent-header dark">
            <div id="header-wrap">
                <div class="container">
                    <div class="header-row justify-content-lg-between">

                        <!-- Logo
						============================================= -->
                        <div id="logo" class="me-lg-0">
                            <a href="./">
                                <img class="logo-default" srcset="assets/images/logo.png" src="assets/images/logo@2x.png" alt="Canvas Logo">
                                <img class="logo-dark" srcset="assets/images/logo-dark.png, assets/images/logo.png" src="assets/images/logo-dark@2x.png" alt="Limpeq Logo">
                            </a>
                        </div><!-- #logo end -->

                        <div class="primary-menu-trigger">
                            <button class="cnvs-hamburger" type="button" title="Open Mobile Menu">
                                <span class="cnvs-hamburger-box"><span class="cnvs-hamburger-inner"></span></span>
                            </button>
                        </div>

                        <!-- Primary Navigation
						============================================= -->
                        <nav class="primary-menu">

                            <ul class="menu-container">
                                <li class="menu-item">
                                    <a class="menu-link" href="index.php">
                                        <div>Home</div>
                                    </a>

                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="./conocenos.php">
                                        <div>Conócenos</div>
                                    </a>

                                </li>
                                <li class="menu-item mega-menu">
                                <li class="menu-item sub-menu">
                                    <a class="menu-link" href="./servicios.php">
                                        <div>Servicios<i class="sub-menu-indicator fa-solid fa-caret-down"></i></div>
                                    </a>
                                    <ul class="sub-menu-container" >
                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-limpieza-de-inmuebles.php">
                                                <div>Servicio limpieza de inmuebles</div>
                                            </a>
                                        </li>
                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-trabajos-eventuales.php">
                                                <div>Trabajos eventuales</div>
                                            </a>
                                        </li>
                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-pulido-de-pisos.php">
                                                <div>Pulido de pisos</div>
                                            </a>
                                        </li>

                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-fumigacion.php">
                                                <div>Fumigación</div>
                                            </a>
                                        </li>

                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-jardineria.php">
                                                <div>Jardinería</div>
                                            </a>
                                        </li> 

                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-limpieza-de-oficinas.php">
                                                <div>Limpieza de oficinas</div>
                                            </a>
                                        </li>

                                      

                                        <li class="menu-item" >
                                            <a class="menu-link" href="./servicio-lavado-de-vidrios-de-altura.php">
                                                <div>Lavado de vidrios de altura</div>
                                            </a>
                                        </li>

                                    </ul>
                                    <button class="sub-menu-trigger fa-solid fa-chevron-right"><span class="visually-hidden">Open Sub-Menu</span></button>
                                </li>

                                </li>


                                <li class="menu-item mega-menu">
                                    <a class="menu-link" href="./contacto.php">
                                        <div>Contacto</div>
                                    </a>
                                </li>

                                <li class="menu-item mega-menu">
                                    <a href="https://wa.me/525529225534" class="button button-rounded button-border button-dark text-end button-icon-effect button-icon-flip-y">Bolsa de trabajo
                                        <i class="bi-briefcase-fill"></i></a>
                                    <!-- <a class="menu-link" href="#">
                                            <div>Bolsa de trabajo</div>
                                        </a> -->
                                </li>

                            </ul>

                        </nav><!-- #primary-menu end -->

                        <form class="top-search-form" action="search.html" method="get">
                            <input type="text" name="q" class="form-control" value placeholder="Type &amp; Hit Enter.." autocomplete="off">
                        </form>

                    </div>
                </div>
            </div>
            <div class="header-wrap-clone"></div>
        </header><!-- #header end -->