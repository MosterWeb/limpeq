<!-- Footer
		============================================= -->
<footer id="footer" class="dark border-0" style="background-image: url('assets/images/bg-footer.jpg'); background-attachment: fixed;">
    <div class="container-fluid px-5">
        <!-- Footer Widgets
				============================================= -->
        <div class="footer-widgets-wrap">

            <div class="row col-mb-50 justify-content-between">
                <div class="col-lg-7">

                    <div class="row col-mb-30">
                        <div class="col-12 col-lg-6 ">
                            <div class="widget widget_links widget-li-noicon">

                                <h4 style="color: #ffffff; text-align: center; ">Servicios</h4>
                            </div>
                            <div class="d-flex">
                                <div class="col-6 col-lg-6">
                                    <div class="widget widget_links widget-li-noicon">

                                        <ul>
                                            <li><a href="./servicios.php#inmuebles">Limpieza de inmuebles</a></li>
                                            <li><a href="./servicios.php#eventuales">Trabajos eventuales</a></li>

                                            <li><a href="./servicios.php#jardineria">Jardinería</a></li>
                                            <li><a href="./servicios.php#fumigacion">Fumigación</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-6 col-lg-6">
                                    <div class="widget widget_links widget-li-noicon">

                                        <ul>
                                            <li><a href="./servicios.php#altura">Lavado de vidrios de altura</a></li>
                                            <li><a href="/servicios.php#pisos">Pulido de pisos</a></li>
                                            <li><a href="/servicios.php#oficinas">Limpieza de oficinas</a></li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-6 col-lg-3">
                            <div class="widget widget_links widget-li-noicon">
                                <h4 style="color: #ffffff">Páginas</h4>
                                <ul>
                                    <li><a href="./conocenos.php">Conócenos</a></li>
                                    <li><a href="./servicios.php">Servicios</a></li>
                                    <li><a href="./contacto.php">Contacto</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-6 col-lg-3">
                            <div class="widget widget_links widget-li-noicon">
                                <h4 style="color: #ffffff">Nosotros</h4>
                                <ul>
                                    <li><a href="https://wa.me/525529225534">Bolsa de
                                            trabajo</a></li>
                                    <li><a href="./preguntas-frecuentes.php">Preguntas
                                            frecuentes</a></li>

                                    <li><a href="./aviso-de-privacidad.php">Aviso de privacidad</a></li>
                                    <li><a href="./contacto.php">Contacto</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-lg-5 text-center text-lg-end">
                    <img src="assets/images/logo-footer.png" alt="Image" height="50">
                    <br>
                    <div style="color: #ffffff">
                        <span>&copy; Limpeq Todos los derechos
                            reservados.</span>
                        <div class="clear"></div>
                        <p style="margin-top: 10px;">Comprometidos con la excelencia y la innovación en servicios de limpieza para crear espacios que potencian el éxito.</p>
                        <p style="margin-top: 10px;">Desarrollado por <a href="https://clicme.marketing/">ClicMe</a></p>
                    </div>
                </div>
            </div>

        </div><!-- .footer-widgets-wrap end -->
    </div>
</footer><!-- #footer end -->

</div><!-- #wrapper end -->

<!-- Go To Top
	============================================= -->
<div id="gotoTop" class="uil uil-angle-up"></div>

<!-- Contact Button
	============================================= -->
<div style="margin-bottom: 20px;" id="contact-me">
    <a href="https://wa.me/525530400966" target="_blank" class="social-icon rounded-circle text-white bg-whatsapp si-large h-bg-whatsapp" title="WhatsApp">
        <i class="fa-brands fa-whatsapp fa-2x"></i>
        <i class="fa-brands fa-whatsapp fa-2x"></i>

    </a>
</div>

<!-- JavaScripts
	============================================= -->
<script src="assets/js/plugins.min.js"></script>
<script src="assets/js/functions.bundle.js"></script>
<script src="assets/demos/car/js/360rotator.js"></script>

<!-- Bootstrap Select Plugin -->
<script src="assets/js/components/bs-select.js"></script>

<!-- SLIDER REVOLUTION 5.x SCRIPTS  -->
<script src="assets/include/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
<script src="assets/include/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

<script src="assets/include/rs-plugin/js/extensions/revolution.extension.actions.min.js"></script>
<script src="assets/include/rs-plugin/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="assets/include/rs-plugin/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="assets/include/rs-plugin/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="assets/include/rs-plugin/js/extensions/revolution.extension.migration.min.js"></script>
<script src="assets/include/rs-plugin/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="include/rs-plugin/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="assets/include/rs-plugin/js/extensions/revolution.extension.slideanims.min.js"></script>


<script defer>
    //Car Appear In View
    function isScrolledIntoView(elem) {
        var docViewTop = jQuery(window).scrollTop();
        var docViewBottom = docViewTop + jQuery(window).height();

        var elemTop = jQuery(elem).offset().top + 180;
        var elemBottom = elemTop + jQuery(elem).height() - 500;

        return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
    }

    jQuery(window).scroll(function() {
        jQuery('.running-car').each(function() {
            if (isScrolledIntoView(this) === true) {
                jQuery(this).addClass('in-view');
            } else {
                jQuery(this).removeClass('in-view');
            }
        });
    });



    // Rev Slider
    var revapi424, tpj = jQuery;

    tpj(document).ready(function() {
        if (tpj("#rev_slider_424_1").revolution == undefined) {
            revslider_showDoubleJqueryError("#rev_slider_424_1");
        } else {
            revapi424 = tpj("#rev_slider_424_1").show().revolution({
                sliderType: "carousel",
                jsFileLocation: "include/rs-plugin/js/",
                sliderLayout: "auto",
                dottedOverlay: "none",
                delay: 7000, // Duración de cada slide en milisegundos
                navigation: {
                    keyboardNavigation: "off",
                    keyboard_direction: "horizontal",
                    mouseScrollNavigation: "off",
                    mouseScrollReverse: "default",
                    onHoverStop: "off", // No detener al pasar el ratón por encima
                    touch: {
                        touchenabled: "on",
                        swipe_threshold: 75,
                        swipe_min_touches: 1,
                        swipe_direction: "horizontal",
                        drag_block_vertical: false
                    },
                    arrows: {
                        style: "uranus",
                        enable: false,
                        hide_onmobile: false,
                        hide_onleave: true,
                        hide_delay: 200,
                        hide_delay_mobile: 1200,
                        tmp: '',
                        left: {
                            h_align: "left",
                            v_align: "center",
                            h_offset: -10,
                            v_offset: 0
                        },
                        right: {
                            h_align: "right",
                            v_align: "center",
                            h_offset: -10,
                            v_offset: 0
                        }
                    },
                    carousel: {
                        maxRotation: 65,
                        vary_rotation: "on",
                        minScale: 55,
                        vary_scale: "on",
                        horizontal_align: "center",
                        vertical_align: "center",
                        fadeout: "on",
                        vary_fade: "on",
                        maxVisibleItems: 5,
                        infinity: "off",
                        space: 0,
                        stretch: "on"
                    },
                    tabs: {
                        style: "ares",
                        enable: true,
                        width: 270,
                        height: 80,
                        min_width: 270,
                        wrapper_padding: 10,
                        wrapper_color: "transparent",
                        wrapper_opacity: "0.5",
                        tmp: '<div class="tp-tab-content">  <span class="tp-tab-date">{{param1}}</span>  <span class="tp-tab-title">{{title}}</span></div><div class="tp-tab-image"></div>',
                        visibleAmount: 7,
                        hide_onmobile: false,
                        hide_under: 420,
                        hide_onleave: false,
                        hide_delay_mobile: 1200,
                        hide_delay: 200,
                        direction: "horizontal",
                        span: true,
                        position: "outer-bottom",
                        space: 20,
                        h_align: "left",
                        v_align: "bottom",
                        h_offset: 0,
                        v_offset: 0
                    }
                },
                visibilityLevels: [1240, 1024, 778, 480],
                gridwidth: [1240, 992, 768, 420],
                gridheight: [600, 500, 960, 720],
                lazyType: "single",
                shadow: 0,
                spinner: "off",
                stopLoop: "off", // Continúa el loop indefinidamente
                stopAfterLoops: -1, // No detener después de ciertos loops
                stopAtSlide: -1, // No detener en una diapositiva específica
                shuffle: "off",
                autoHeight: "off",
                hideThumbsOnMobile: "off",
                hideSliderAtLimit: 0,
                hideCaptionAtLimit: 0,
                hideAllCaptionAtLilmit: 0,
                debugMode: false,
                fallbacks: {
                    simplifyAll: "off",
                    nextSlideOnWindowFocus: "off",
                    disableFocusListener: false,
                }
            });
        }
    });
    /*ready*/

    window.addEventListener('load', function() {

        document.getElementById('loading-rel').style.display = 'none';
    });
</script>


</body>

</html>